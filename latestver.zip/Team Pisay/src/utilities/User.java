package utilities;

/*
    NUSH Hackathon Team Pisay
    David, Mogen Malks 
    Esguerra, Jamie
    Ortiz, Celver Zitro H.
 */

/**
 *
 * @author malks
 */

public class User {
    
    private static String username;
    
    // Returns the usernme of the current user
    public static String getUsername(){
        return username;
    }
    
    // Sets the stored username
    public static void setUsername(String name){
        username = name;
    }
}
