public class Water extends CarbonSources {
  private double waterCarbonFootprint;

  public Water(int aC){
    super(aC);
    this.carbonProduced = 0.149*amountConsumed;
    // carbon produced = emission factor * cubic meters of water
    waterCarbonFootprint = waterCarbonFootprint + carbonProduced;
  }
  
  @Override
  public double getCF(){
      return waterCarbonFootprint;
  }
}