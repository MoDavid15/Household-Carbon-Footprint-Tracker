/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

import utilities.User;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ButtonBar.ButtonData;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Dialog;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import network.Conn;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class LoginController implements Initializable {

    @FXML private TextField name;
    @FXML private PasswordField password;
    @FXML private Text error;
    
    @FXML private void goBack(ActionEvent event) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Start.fxml"));
            Stage stage = new Stage();
            Scene scene = new Scene(root);
            stage.setScene(scene);

            Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
            thisStage.close();
            stage.setResizable(false);
            stage.show();
    }
    
    @FXML private void login(ActionEvent event) throws IOException {
        String username = name.getText();
        String pw = password.getText();  
        
        //arrange errors by specific to general
        if (username.isEmpty()){
            error.setVisible(true);
            error.setText("Error: Username is required");
        }
        else if (pw.isEmpty()){
            error.setVisible(true);
            error.setText("Error: Password is required");
        }
        else {
            
            String response = "";
            HashMap<String, String> params = new HashMap<>();
            params.put("username", username);
            params.put("password", pw);
        
            try {
                response = Conn.post("https://Household-Carbon-Footprint-Tracker.modavid.repl.co/login", params);
            } catch (UnsupportedEncodingException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            } catch (IOException ex) {
                Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
            }
        
            if(response.equals("loggedIn")){
                
                // Store the user name in the User class
                User.setUsername(username);
                
                // Log in and show main panel
                Parent root = FXMLLoader.load(getClass().getResource("Home.fxml"));
                Stage stage = new Stage();
                Scene scene = new Scene(root);
                stage.setScene(scene);

                Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
                thisStage.close();
                stage.setResizable(false);
                stage.show();
            } else {
                
                // In case password is incorrect or smth
                Dialog<String> dialog = new Dialog<>();
                ButtonType ok = new ButtonType("Ok", ButtonData.OK_DONE);
                
                dialog.setTitle("Wrong Credentials.");
                dialog.setContentText("The username or password was not correct.");
                dialog.getDialogPane().getButtonTypes().add(ok);
                dialog.showAndWait();
            }
        }        
    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        //textfield name
        //passwordfield password
        //text error (for error message)
                //the username inputted is not in the list of users
                //username/password required
                //the password doesn't match with the username
                //the username is taken
    }    
    
}
