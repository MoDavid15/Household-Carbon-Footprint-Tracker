/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

/**
 *
 * @author celver ortiz
 */
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Label;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.layout.AnchorPane;
import java.util.Timer;
import java.util.TimerTask;
import utilities.funcs;


/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class HomeController implements Initializable {
    
    @FXML private CategoryAxis x;
    @FXML private NumberAxis y;
    @FXML private AnchorPane imageContainer;
    
    @FXML private void goTo(MouseEvent event) throws IOException {
        String id = ((Node)event.getSource()).getId();
        
            Parent root = FXMLLoader.load(getClass().getResource(id + ".fxml"));
		Stage stage = new Stage();
                Scene scene = new Scene(root);
		stage.setScene(scene);
		
		Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		thisStage.close();
                stage.setResizable(false);
                stage.show();
    }
    
    @FXML private Label carbonFootprint, electricityFootprint, waterFootprint, transpoFootprint;
    @FXML private DecimalFormat format = new DecimalFormat("#.00"); //kinda important for display
    
    @FXML private void carbonUpdate(){ //di ako sure if dito dapat to, tester lang ata to ni jamie, c
        CarbonSources test = new Electricity(100);
        test.totalFootprintCounter();
        carbonFootprint.setText(String.valueOf(format.format(test.getCProduced()))); //can be transferred in intialization yung pag initialize ng labels
    }
    @FXML private void waterUpdate(){
        CarbonSources test1 = new Water(100);
        waterFootprint.setText(String.valueOf(format.format(test1.getCF())));
    }
    @FXML private void electricityUpdate(){
        CarbonSources test2 = new Electricity(100);
        electricityFootprint.setText(String.valueOf(format.format(test2.getCF())));
    }
    /* @FXML private void transpoUpdate(){
        CarbonSources test3 = new Transportation(100);
        electricityFootprint.setText(String.valueOf(test3.getCF()));
    } */ //wala pang transpo java

  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // Grab data from the server
        funcs.getDataCommunal(imageContainer);
        funcs.getDataPersonal();
        
        // Set a fixed interval for data sending-pulses
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask(){
            
            @Override
            public void run() {
                funcs.addData();
            }
            
        }, 500, 20000);
        
        
        // Set the displayed data
        carbonFootprint.setText("test");
    }    
    
}
