package utilities;

/*
    NUSH Hackathon Team Pisay
    David, Mogen Malks 
    Esguerra, Jamie
    Ortiz, Celver Zitro H.
 */

/**
 *
 * @author malks
 */

public class User {
    
    private static String username;
    private static double electricity;
    private static double water;
    private static double transportation;
    
    // Returns the usernme of the current user
    public static String getUsername(){
        return username;
    }
    
    public static double getElectricity(){
        return electricity;
    }
    
    public static double getWater(){
        return water;
    }
    
    public static double getTransportation(){
        return transportation;
    }
    
    // Sets the stored username
    public static void setUsername(String name){
        username = name;
    }
    
    public static void setElectricity(double elec){
        electricity = elec;
    }
    
    public static void setWater(double wat){
        water = wat;
    }
    
    public static void setTransportation(double transpo){
        transportation = transpo;
    }
}
