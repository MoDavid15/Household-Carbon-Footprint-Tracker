/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utilities;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.AnchorPane;
import javax.imageio.ImageIO;
import network.Conn;
import java.lang.Math;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

/**
 *
 * @author malks
 */
public class funcs {
    
    // Retrieves data from the server
    public static void getDataPersonalWeekly(){
        // Grab the data from the server
        String response = "";
        HashMap<String, String> params = new HashMap<>();
        params.put("username", User.getUsername());

        try {
            response = Conn.get("https://Household-Carbon-Footprint-Tracker.modavid.repl.co/getData/personalweekly", params);
        } catch (UnsupportedEncodingException ex) {
        } catch (IOException ex) {}
    }
    
    // Retrieves data from the server
    public static void getDataPersonalSummary(){
        // Grab the data from the server
        String response = "";
        HashMap<String, String> params = new HashMap<>();
        params.put("username", User.getUsername());

        try {
            response = Conn.get("https://Household-Carbon-Footprint-Tracker.modavid.repl.co/getData/personalsummary", params);
        } catch (UnsupportedEncodingException ex) {
        } catch (IOException ex) {}
        
        // Convert to json and gather data
        JSONParser parser = new JSONParser();
        JSONObject json = null;
        try {
            json = (JSONObject) parser.parse(response);
        } catch (ParseException ex) {
            Logger.getLogger(funcs.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        if(json.get("electricity") != null){
            User.setElectricity((double) json.get("electricity"));
        }
        
        if(json.get("water") != null){
            User.setElectricity((double) json.get("water"));
        }
        
        if(json.get("transportation") != null){
            User.setElectricity((double) json.get("transportation"));
        }
    }
    
    public static void getDataCommunal(AnchorPane imageContainer){
        
        // Grab the data from the server
        String response = "";
        HashMap<String, String> params = new HashMap<>();

        try {
            response = Conn.get("https://Household-Carbon-Footprint-Tracker.modavid.repl.co/getData/communal", params);
        } catch (UnsupportedEncodingException ex) {
        } catch (IOException ex) {}
        
        // Convert the response to a stream
        String base64Image = response.split(",")[1];
        byte[] imageBytes = javax.xml.bind.DatatypeConverter.parseBase64Binary(base64Image);
        try {
            BufferedImage img = ImageIO.read(new ByteArrayInputStream(imageBytes));
            File outputfile = new File("image.png");
            ImageIO.write(img, "png", outputfile);
        } catch (IOException ex) {}
        
        // Creating the image object
        InputStream stream;
        try {
            stream = new FileInputStream("image.png");
            
            // Add the image into the home screen
            Image image = new Image(stream);
            ImageView imageView = new ImageView();
            
            imageView.setImage(image);
            imageView.setFitWidth(400);
            imageView.setPreserveRatio(true);
            imageContainer.getChildren().add(imageView);
            
        } catch (FileNotFoundException ex) {}
    }
    
    // Pushes new data to the server
    public static void addData(){
        
        // Create post request for pushing data to server
        String response = "";
        HashMap<String, String> params = new HashMap<>();
        
        // Set up the parameters to send
        params.put("username", User.getUsername());
        params.put("electricity", Math.random() + "");
        params.put("water", Math.random() + "");
        params.put("trasnportation", Math.random() + "");
        
        try {
            response = Conn.post("https://Household-Carbon-Footprint-Tracker.modavid.repl.co/addData", params);
        } catch (UnsupportedEncodingException ex) {
        } catch (IOException ex) {}
    }
}
