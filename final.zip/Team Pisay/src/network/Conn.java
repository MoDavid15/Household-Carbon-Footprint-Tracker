/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package network;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URLConnection;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Scanner;
import org.json.simple.*;

/**
 *
 * @author malks
 */
public class Conn {
    
    public static String get(String url, HashMap<String, String> params) throws ProtocolException, UnsupportedEncodingException, IOException{

        // Set up the request body
        String query = "";
        int index = 0;
        
        for(String key : params.keySet()){
            index++;
            query += key + "=" + URLEncoder.encode(params.get(key), "UTF-8");
            
            if(index != params.keySet().size()){
                query += "&";
            }
        }
        
        URLConnection connection = new URL(url + "?" + query).openConnection();
        connection.setRequestProperty("Accept-Charset", "UTF-8");
        InputStream response = connection.getInputStream();
        
        // Debugging tingz
        try (Scanner scanner = new Scanner(response)) {
            String responseBody = scanner.useDelimiter("\\A").next();
            return responseBody;
        }
    }
    
    public static String post(String url, HashMap<String, String> params) throws ProtocolException, UnsupportedEncodingException, IOException{
        
        // Set up the request body
        HttpURLConnection connection = (HttpURLConnection)((new URL(url)).openConnection());
        String query = "";
        int index = 0;
        
        for(String key : params.keySet()){
            index++;
            query += key + "=" + URLEncoder.encode(params.get(key), "UTF-8");
            
            if(index != params.keySet().size()){
                query += "&";
            }
        }
        
        byte[] postData = query.getBytes( StandardCharsets.UTF_8 );
        int postDataLength = postData.length;
        
        // Set up the request
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded"); 
        connection.setRequestProperty("Content-Length", Integer.toString(postDataLength ));
        connection.setDoOutput(true);
        
        try(DataOutputStream wr = new DataOutputStream(connection.getOutputStream())) {
            wr.write( postData );
        }
        
        try(BufferedReader br = new BufferedReader(
            new InputStreamReader(connection.getInputStream(), "utf-8"))) {
            StringBuilder response = new StringBuilder();
            String responseLine = null;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            return (response.toString());
        }
    }
}
