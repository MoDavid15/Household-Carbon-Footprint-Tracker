public class Electricity extends CarbonSources {
  private double electricityCarbonFootprint;

  public Electricity(int aC){
    super(aC);
    this.carbonProduced = 0.21233*amountConsumed;
    // carbon produced = emission factor * kWh of electricity
    electricityCarbonFootprint = electricityCarbonFootprint + carbonProduced;
  }
  
  @Override
  public double getCF(){
      return electricityCarbonFootprint;
  }
}