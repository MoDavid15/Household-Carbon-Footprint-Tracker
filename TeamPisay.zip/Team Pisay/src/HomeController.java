/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

/**
 *
 * @author celver ortiz
 */
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.animation.KeyFrame;
import javafx.animation.KeyValue;
import javafx.animation.Timeline;
import javafx.beans.property.DoubleProperty;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class HomeController implements Initializable {
    
    @FXML private ImageView op;
    @FXML private Pane options;
    @FXML private BarChart barChart;
    @FXML private CategoryAxis x;
    @FXML private NumberAxis y;
    @FXML private PieChart pieChart;
    
    @FXML private Timeline rot = new Timeline();
    @FXML private Timeline sld = new Timeline();
    
    @FXML private void goTo(MouseEvent event) throws IOException {
        String id = ((Node)event.getSource()).getId();
        
            Parent root = FXMLLoader.load(getClass().getResource(id + ".fxml"));
		Stage stage = new Stage();
                Scene scene = new Scene(root);
		stage.setScene(scene);
		
		Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		thisStage.close();
                stage.setResizable(false);
                stage.show();
    }
    
    @FXML
    private void showOpts(MouseEvent event) throws IOException {
        
        if(Main.optsClose == true){
        
        DoubleProperty r = op.rotateProperty();
        
        rot.getKeyFrames().addAll(
                new KeyFrame(new Duration(0), new KeyValue(r,0)),
                new KeyFrame(new Duration(500), new KeyValue(r,360))
        );
        
        rot.play();
        
        DoubleProperty s = options.translateXProperty();
        
        sld.getKeyFrames().addAll(
                new KeyFrame(new Duration(0), new KeyValue(s,0)),
                new KeyFrame(new Duration(500), new KeyValue(s,200))
        );
        
       sld.play();
       
       Main.optsClose = false;
       }
       
        if (Main.optsClose == false) {
            DoubleProperty r = op.rotateProperty();
        
        rot.getKeyFrames().addAll(
                new KeyFrame(new Duration(0), new KeyValue(r,0)),
                new KeyFrame(new Duration(500), new KeyValue(r,-360))
        );
        
        rot.play();
        
        DoubleProperty s = options.translateXProperty();
        
        sld.getKeyFrames().addAll(
                new KeyFrame(new Duration(0), new KeyValue(s,0)),
                new KeyFrame(new Duration(500), new KeyValue(s,-200))
        );
        
       sld.play();
       
       Main.optsClose = true;
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Main.optsClose = true;
        
        XYChart.Series weekly = new XYChart.Series<>();
        
        weekly.getData().add(new XYChart.Data("Mon",200));
        weekly.getData().add(new XYChart.Data("Tues", 200));
        weekly.getData().add(new XYChart.Data("Wed", 200));
        weekly.getData().add(new XYChart.Data("Thurs", 200));
        weekly.getData().add(new XYChart.Data("Fri", 300));
        weekly.getData().add(new XYChart.Data("Sat", 200));
        weekly.getData().add(new XYChart.Data("Sun", 200));
        
        barChart.getData().addAll(weekly);
    }    
    
}
