/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
*/

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class UserController implements Initializable {

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
