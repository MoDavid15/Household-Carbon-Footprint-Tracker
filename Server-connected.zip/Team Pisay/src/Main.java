
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import network.Conn;

/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

/**
 *
 * @author celver ortiz
 */
public class Main extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        Parent root = FXMLLoader.load(getClass().getResource("Start.fxml"));
        
        Scene scene = new Scene(root);
        
        stage.setScene(scene);
        stage.show();
	stage.setResizable(false);
    }

    public static void main(String[] args) {
        launch();
    }
}
