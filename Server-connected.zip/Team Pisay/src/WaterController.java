/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

/**
 *
 * @author celver ortiz
 */
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.PieChart;
import javafx.scene.chart.XYChart;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class WaterController implements Initializable {
    
    @FXML private BarChart barChart;
    @FXML private CategoryAxis x;
    @FXML private NumberAxis y;
    
    @FXML private void goTo(MouseEvent event) throws IOException {
        String id = ((Node)event.getSource()).getId();
        
            Parent root = FXMLLoader.load(getClass().getResource(id + ".fxml"));
		Stage stage = new Stage();
                Scene scene = new Scene(root);
		stage.setScene(scene);
		
		Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		thisStage.close();
                stage.setResizable(false);
                stage.show();
    }
  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        XYChart.Series weekly = new XYChart.Series<>();
        
        weekly.getData().add(new XYChart.Data("Mon",200));
        weekly.getData().add(new XYChart.Data("Tues", 200));
        weekly.getData().add(new XYChart.Data("Wed", 200));
        weekly.getData().add(new XYChart.Data("Thurs", 200));
        weekly.getData().add(new XYChart.Data("Fri", 300));
        weekly.getData().add(new XYChart.Data("Sat", 200));
        weekly.getData().add(new XYChart.Data("Sun", 200));

        barChart.getData().addAll(weekly);
        
        barChart.lookup(".data0.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
        barChart.lookup(".data1.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
        barChart.lookup(".data2.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
        barChart.lookup(".data3.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
        barChart.lookup(".data4.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
        barChart.lookup(".data5.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
        barChart.lookup(".data6.chart-bar").setStyle("-fx-bar-fill: #4d9be6");
    }    
    
}
