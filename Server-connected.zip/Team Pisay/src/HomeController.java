/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

/**
 *
 * @author celver ortiz
 */
import java.awt.image.BufferedImage;
import java.awt.image.RenderedImage;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import network.Conn;
import java.io.ByteArrayInputStream;
import java.io.File;
import javax.imageio.ImageIO;
import sun.misc.BASE64Decoder;
import utilities.funcs;


/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class HomeController implements Initializable {
    
    @FXML private CategoryAxis x;
    @FXML private NumberAxis y;
    @FXML private AnchorPane imageContainer;
    
    @FXML private void goTo(MouseEvent event) throws IOException {
        String id = ((Node)event.getSource()).getId();
        
            Parent root = FXMLLoader.load(getClass().getResource(id + ".fxml"));
		Stage stage = new Stage();
                Scene scene = new Scene(root);
		stage.setScene(scene);
		
		Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		thisStage.close();
                stage.setResizable(false);
                stage.show();
    }
    
    @FXML private Label carbonFootprint, electricityFootprint, waterFootprint, transpoFootprint;
    @FXML private DecimalFormat format = new DecimalFormat("#.00"); //kinda important for display
    
    @FXML private void carbonUpdate(){ //di ako sure if dito dapat to, tester lang ata to ni jamie, c
        CarbonSources test = new Electricity(100);
        test.totalFootprintCounter();
        carbonFootprint.setText(String.valueOf(format.format(test.getCProduced()))); //can be transferred in intialization yung pag initialize ng labels
    }
    @FXML private void waterUpdate(){
        CarbonSources test1 = new Water(100);
        waterFootprint.setText(String.valueOf(format.format(test1.getCF())));
    }
    @FXML private void electricityUpdate(){
        CarbonSources test2 = new Electricity(100);
        electricityFootprint.setText(String.valueOf(format.format(test2.getCF())));
    }
    /* @FXML private void transpoUpdate(){
        CarbonSources test3 = new Transportation(100);
        electricityFootprint.setText(String.valueOf(test3.getCF()));
    } */ //wala pang transpo java

  
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        funcs.getData(imageContainer);
    }    
    
}
