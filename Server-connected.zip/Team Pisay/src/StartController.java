/*
NUSH Hackathon Team Pisay
David, Mogen Malks 
Esguerra, Jamie
Ortiz, Celver Zitro H.
 */

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author celver ortiz
 */
public class StartController implements Initializable {

    @FXML private void goTo(ActionEvent event) throws IOException {
        String id = ((Node)event.getSource()).getId();
        
            Parent root = FXMLLoader.load(getClass().getResource(id + ".fxml"));
		Stage stage = new Stage();
                Scene scene = new Scene(root);
		stage.setScene(scene);
		
		Stage thisStage = (Stage)((Node)event.getSource()).getScene().getWindow();
		thisStage.close();
                stage.setResizable(false);
                stage.show();
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
