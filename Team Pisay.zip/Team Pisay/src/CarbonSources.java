public abstract class CarbonSources{
    protected int amountConsumed;
    protected double carbonProduced;
    protected double totalFootprint = 0;

  //constructor
    public CarbonSources(int aC){
      this.amountConsumed = aC;
      this.carbonProduced = aC;
    }

  //getters
    public int getAmtConsumed() {
      return amountConsumed;
    }
    public double getCProduced() {
      return carbonProduced;
    }
    public double getTotalFootprint() {
      return totalFootprint;
    }

    public void totalFootprintCounter(){
      totalFootprint = totalFootprint + carbonProduced;
    }
    
    public abstract double getCF();
}